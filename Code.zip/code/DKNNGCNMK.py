import torch as t
from torch import nn
from torch_geometric.nn import conv
from utils import *


class Model(nn.Module):
    def __init__(self, sizes, dise_sim, mic_sim):
        super(Model, self).__init__()
        np.random.seed(sizes.seed)
        t.manual_seed(sizes.seed)
        self.dise_size = sizes.dise_size
        self.mic_size = sizes.mic_size
        self.F1 = sizes.F1
        self.F2 = sizes.F2
        self.F3 = sizes.F3
        self.seed = sizes.seed

        self.dilation_rate = sizes.dilation_rate
        self.k_neighbors = sizes.k_neighbors
        self.h1_gamma = sizes.h1_gamma
        self.h2_gamma = sizes.h2_gamma
        self.h3_gamma = sizes.h3_gamma

        self.lambda1 = sizes.lambda1
        self.lambda2 = sizes.lambda2

        self.kernel_len = 4
        self.drug_ps = t.ones(self.kernel_len) / self.kernel_len
        self.mic_ps = t.ones(self.kernel_len) / self.kernel_len

        self.dise_sim = t.DoubleTensor(dise_sim)
        self.mic_sim = t.DoubleTensor(mic_sim)

        self.gcn_1 = conv.GCNConv(self.dise_size + self.mic_size, self.F1)
        self.gcn_2 = conv.GCNConv(self.F1, self.F2)
        self.gcn_3 = conv.GCNConv(self.F2, self.F3)

        self.alpha1 = t.randn(self.dise_size, self.mic_size).double()
        self.alpha2 = t.randn(self.mic_size, self.dise_size).double()

        self.drug_l = []
        self.mic_l = []

        self.drug_k = []
        self.mic_k = []


    def forward(self, input):
        t.manual_seed(self.seed)
        x = input['feature']
        adj = input['Adj']
        drugs_kernels = []
        mic_kernels = []
        
        H1 = t.relu(self.gcn_1(x, adj['edge_index'], adj['data'][adj['edge_index'][0], adj['edge_index'][1]])) 
        #torch.Size([1546, 128])
        # H1 = t.relu(self.gcn_1(x, dilated_adj))
        print(H1.shape)
        print('finish!!')        
        drugs_kernels.append(t.DoubleTensor(getGipKernel(H1[:self.dise_size].clone(), 0, self.h1_gamma, True).double()))
        mic_kernels.append(t.DoubleTensor(getGipKernel(H1[self.dise_size:].clone(), 0, self.h1_gamma, True).double()))
        print("Shape after Conv1d_1:", H1.shape)
        
        H2 = t.relu(self.gcn_2(H1, adj['edge_index'], adj['data'][adj['edge_index'][0], adj['edge_index'][1]]))
        # torch.Size([1546, 64])
        drugs_kernels.append(t.DoubleTensor(getGipKernel(H2[:self.dise_size].clone(), 0, self.h2_gamma, True).double()))
        mic_kernels.append(t.DoubleTensor(getGipKernel(H2[self.dise_size:].clone(), 0, self.h2_gamma, True).double()))
        print("Shape after Conv1d_2:", H2.shape)
        
        H3 = t.relu(self.gcn_3(H2, adj['edge_index'], adj['data'][adj['edge_index'][0], adj['edge_index'][1]]))
        # torch.Size([1546, 32])
        drugs_kernels.append(t.DoubleTensor(getGipKernel(H3[:self.dise_size].clone(), 0, self.h3_gamma, True).double()))
        mic_kernels.append(t.DoubleTensor(getGipKernel(H3[self.dise_size:].clone(), 0, self.h3_gamma, True).double()))
        print("Shape after Conv1d_3:", H3.shape)
        # drugs_kernels[0]=self.dise_sim[0]
        # drugs_kernels[1]=self.dise_sim[0]
        # drugs_kernels[2]=self.dise_sim[0]
        # mic_kernels[0]=self.mic_sim[0]
        # mic_kernels[1]=self.mic_sim[0]
        # mic_kernels[2]=self.mic_sim[0]
        # # drugs_kernels = [self.dise_sim] + drugs_kernels[1:]
        # # mic_kernels = [self.mic_sim] + mic_kernels[1:]
        # print("drugs_kernels 长度:", drugs_kernels[0].shape)
        # print("drugs_kernels 长度:", drugs_kernels[1].shape)
        # print("drugs_kernels 长度:", drugs_kernels[2].shape)
        # print("mic_kernels 长度:", mic_kernels[0].shape)
        # print("mic_kernels 长度:", mic_kernels[1].shape)
        # print("mic_kernels 长度:", mic_kernels[2].shape)
        drugs_kernels.append(self.dise_sim)
        mic_kernels.append(self.mic_sim)
        print("drugs_kernels 长度:", len(drugs_kernels[0].shape))
        print("mic_kernels 长度:", len(mic_kernels))
        drug_k = sum([self.drug_ps[i] * drugs_kernels[i] for i in range(len(self.drug_ps))])
        #核矩阵的归一化处理
        self.drug_k = normalized_kernel(drug_k)
        mic_k = sum([self.mic_ps[i] * mic_kernels[i] for i in range(len(self.mic_ps))])
        #核矩阵的归一化处理
        self.mic_k = normalized_kernel(mic_k)
        print(drug_k.shape)
        print(mic_k.shape)
        self.drug_l = laplacian(drug_k)
        self.mic_l = laplacian(mic_k)

        out1 = t.mm(self.drug_k, self.alpha1)
        out2 = t.mm(self.mic_k, self.alpha2)
        print("2222223243433455")
        print(out1.shape)
        print(out2.shape)
        out = (out1 + out2.T) / 2
        print(out.shape)
        print("0123456789876655")
        return out                                                                                                  
 


    # def dilated_knn(self, x, dilation, k_neighbors):
    # # 根据Dilated k-NN方法定义邻域
    # # 注意：这里只是一个简单的示例，实际中可能需要更复杂的邻域定义

    #     num_nodes = x.size(0)
    #     num_features = x.size(1)
        
    #     # 初始化一个与输入特征相同大小的矩阵，用于存储新的特征表示
    #     new_features = t.zeros_like(x, dtype=t.float32)

    #     # 使用 Minkowski 距离作为度量
    #     distance_matrix = t.pairwise_distance(x, x, p=2)  # 使用 L2 范数
        
    #     for i in range(num_nodes):
    #         # 计算基于 Minkowski 距离的最近邻
    #         _, neighbors = t.topk(-distance_matrix[i], k_neighbors).indices

    #         # 将邻居节点的特征加权求和，作为新的节点特征表示
    #         new_features[i] = t.mean(x[neighbors], dim=0)
    #     return new_features



    