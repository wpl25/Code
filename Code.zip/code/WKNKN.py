import numpy as np
from scipy.spatial import distance
import random
import math

def WKNKN1(MD_mat, MM_mat, DD_mat, K, r):
    rows, cols = MD_mat.shape
    y_m = np.zeros((rows, cols))
    y_d = np.zeros((rows, cols))

    # KNN for miRNA
    knn_network_m = KNN(MM_mat, K)
    # print(knn_network_m)
    for i in range(rows):
        w = np.zeros(K)
        sort_m = np.sort(knn_network_m[i, :], axis=0)[::-1]
        idx_m = np.argsort(knn_network_m[i, :], axis=0)[::-1]
        
        # print(sort_m)
        optimal_MM = find_optimal_k(sort_m,K,rows-K)

        sum_m = np.sum(sort_m[:K:optimal_MM])
        # print(optimal_MM)
        for j in range(0,K,optimal_MM):
            w[j] = r**(j) * sort_m[j]
            y_m[i, :] += w[j] * MD_mat[idx_m[j], :]
        y_m[i, :] /= sum_m

    # KNN for disease
    knn_network_d = KNN(DD_mat, K)
    for i in range(cols):
        w = np.zeros(K)
        sort_d, idx_d = np.sort(knn_network_d[i, :], axis=0)[::-1], np.argsort(knn_network_d[i, :], axis=0)[::-1]
        
        optimal_DD = find_optimal_k(sort_d, K,cols-K)
        sum_d = np.sum(sort_d[:K:optimal_DD])
        for j in range(0,K,optimal_DD):
            w[j] = r**(j) * sort_d[j]
            y_d[:, i] += w[j] * MD_mat[:, idx_d[j]]
        y_d[:, i] /= sum_d

    a1, a2 = 0.3, 0.7
    y_md = (y_m * a1 + y_d * a2) / (a1 + a2)

    MD_mat_new = np.maximum(MD_mat, y_md)

    return MD_mat_new

def KNN(network, k):
    rows, cols = network.shape
    max_iterations1=30
    network = network - np.diag(np.diag(network))
    knn_network = np.zeros((rows, cols))
    idx = np.argsort(network, axis=1)[:, ::-1]
    for i in range(rows):
        knn_network[i, idx[i, :]] = network[i, idx[i, :]]
    return knn_network

def find_optimal_k(weights, k,  max_iterations):
    for i in range(1,  max_iterations):
        current_avg_k = np.mean(weights[:k+i])
        current_avg_k_plus_i = np.mean(weights[:k+i+1])

        diff_sum = np.sum(weights[:k+i+1]) - np.sum(weights[:k+i])
        current_avg_k = np.mean(weights[:k+i])
        if np.abs(current_avg_k-current_avg_k_plus_i) > 0.01:
            k += 1  # 继续增加k
        else:
            return math.ceil(i/5)  # 返回i值
    return math.ceil(max_iterations/5)  # 达到最大迭代次数仍未满足条件，返回最大迭代次数
        # diff_avg = current_avg_k - current_avg_k_plus_i
        # current_avg_k = np.mean(weights[:k+i])
        # current_avg_k_plus_i = np.mean(weights[:k+i+1])
        # print(current_avg_k - current_avg_k_plus_i)
        # print("平均数的差"+str(diff_avg))
        # print("和的差"+str(diff_sum))

        # diff = np.sum(weights[:k+i+1]) - np.sum(weights[:k+i])
        # if diff <  threshold :
        #     return 1  # 平均值近似相等，返回0
        # print(i)
        # print(diff)
        # if np.abs(diff_avg) < threshold:
        #     return 1  # 平均值近似相等，返回1
