import numpy as np
import scipy.sparse as sp
import random
import gc

from clac_metric import get_metrics
from utils import constructHNet, constructNet, get_edge_index, Sizes
import torch as t
from torch import optim
from loss import Myloss
from sklearn.metrics import roc_curve, auc,precision_recall_curve
import matplotlib.pyplot as plt

import pandas as pd

import MDGCN
import WKNKN 

def train(model, train_data, optimizer, sizes):
    model.train()
    regression_crit = Myloss()

    def train_epoch():
        #每一轮训练之前，需要将上一轮计算得到的参数梯度清零，以便进行新一轮的梯度计算
        model.zero_grad()
        score = model(train_data)

        loss = regression_crit(train_data['Y_train'], score, model.drug_l, model.mic_l, model.alpha1,
                               model.alpha2, sizes)
        model.alpha1 = t.mm(
            t.mm((t.mm(model.drug_k, model.drug_k) + model.lambda1 * model.drug_l).inverse(), model.drug_k),
            2 * train_data['Y_train'] - t.mm(model.alpha2.T, model.mic_k.T)).detach()
        model.alpha2 = t.mm(t.mm((t.mm(model.mic_k, model.mic_k) + model.lambda2 * model.mic_l).inverse(), model.mic_k),
                            2 * train_data['Y_train'].T - t.mm(model.alpha1.T, model.drug_k.T)).detach()
        loss = loss.requires_grad_()#确保 loss 张量需要梯度信息
        loss.backward()#反向传播，计算梯度
        optimizer.step()#计算 loss 对模型参数的梯度
        return loss

    for epoch in range(1, sizes.epoch + 1):
        train_reg_loss = train_epoch()
        print("epoch : %d, loss:%.2f" % (epoch, train_reg_loss.item()))
    pass


def PredictScore(train_dise_mic_matrix, dise_matrix, mic_matrix, seed, sizes):
    np.random.seed(seed)
    train_data = {}
    train_data['Y_train'] = t.DoubleTensor(train_dise_mic_matrix)
    Heter_adj = constructHNet(train_dise_mic_matrix, dise_matrix, mic_matrix)#三网融合构建异构网络
    Heter_adj = t.FloatTensor(Heter_adj)
    Heter_adj_edge_index = get_edge_index(Heter_adj)
    train_data['Adj'] = {'data': Heter_adj, 'edge_index': Heter_adj_edge_index}

    X = constructNet(train_dise_mic_matrix)
    X = t.FloatTensor(X)#将数组转换为张量
    train_data['feature'] = X

    model = MDGCN.Model(sizes, dise_matrix, mic_matrix)
    print(model)
    # 返回一个包含模型所有参数的迭代器
    for parameters in model.parameters():
        print(parameters, ':', parameters.size())
    # 创建了一个优化器对象
    optimizer = optim.Adam(model.parameters(), lr=sizes.learn_rate)

    train(model, train_data, optimizer, sizes)
    return model(train_data)


def random_index(index_matrix, sizes):
    association_nam = index_matrix.shape[1]#1表示关联，而这里面表示了关联的数量
    random_index = index_matrix.T.tolist()#变成[ [0,0], [0,1], [0,2]  ]类似于这个样子
    random.seed(sizes.seed)
    random.shuffle(random_index)#对上面进行打乱
    k_folds = sizes.k_fold
    CV_size = int(association_nam / k_folds)
    temp = np.array(random_index[:association_nam - association_nam %
                                  k_folds]).reshape(k_folds, CV_size, -1).tolist()
    temp[k_folds - 1] = temp[k_folds - 1] + \
                        random_index[association_nam - association_nam % k_folds:]
    return temp


def crossval_index(dise_mic_matrix, sizes):
    random.seed(sizes.seed) #固定模型训练过程中所产生的随机数，从而在对所描述模型进行复现的时候可以最大程度地逼近描述效果
    pos_index_matrix = np.mat(np.where(dise_mic_matrix == 1))#两行多列的数组，对应表示为1的索引
    
    neg_index_matrix = np.mat(np.where(dise_mic_matrix == 0))
    pos_index = random_index(neg_index_matrix, sizes)
    neg_index = random_index(pos_index_matrix, sizes)
    index = [pos_index[i] + neg_index[i] for i in range(sizes.k_fold)]
    return index


def cross_validation_experiment(dise_mic_matrix, dise_matrix, mic_matrix, sizes):
    index = crossval_index(dise_mic_matrix, sizes)
    metric = np.zeros((1, 7))

    fpr1=0
    tpr1=0
    #储存预测得分
    pre_matrix = np.zeros(dise_mic_matrix.shape)
    print("seed=%d, evaluating drug-microbe...." % (sizes.seed))
    for k in range(sizes.k_fold):
        print("------this is %dth cross validation------" % (k + 1))
        train_matrix = np.matrix(dise_mic_matrix, copy=True)#创建副本，独立内存地址，不改变之前的
        train_matrix[tuple(np.array(index[k]).T)] = 0#将这部分保留作为测试集 根据索引位置将矩阵中的值置为0
        drug_len = dise_mic_matrix.shape[0]
        dis_len = dise_mic_matrix.shape[1]
        drug_mic_res = PredictScore(
            train_matrix, dise_matrix, mic_matrix, sizes.seed, sizes)
        predict_y_proba = drug_mic_res.reshape(drug_len, dis_len).detach().numpy()#将预测结果进行形状调整，使其与输入数据的形状相匹配
        pre_matrix[tuple(np.array(index[k]).T)] = predict_y_proba[tuple(np.array(index[k]).T)]#对应位置的预测结果赋值给 pre_matrix
        metric_tmp,fpr,tpr = get_metrics(dise_mic_matrix[tuple(np.array(index[k]).T)],
                                 predict_y_proba[tuple(np.array(index[k]).T)])
        metric += metric_tmp
        fpr1+=fpr
        tpr1+=tpr
        del train_matrix
        gc.collect()
    print(metric / sizes.k_fold)
    fpr1=fpr1/sizes.k_fold
    tpr1=tpr1/sizes.k_fold
    metric = np.array(metric / sizes.k_fold)
    return metric, pre_matrix,fpr1,tpr1

def loocv_experiment(dise_mic_matrix, dise_matrix, mic_matrix, sizes):
    metric_sum = np.zeros((1, 7))  # 用于累积指标的总和
    fpr_sum = 0
    tpr_sum = 0

    pre_matrix = np.zeros(dise_mic_matrix.shape)

    for i in range(dise_mic_matrix.shape[0]):  # 遍历每个样本
        print("------this is %dth cross validation------" % (i + 1))
        train_matrix = np.delete(dise_mic_matrix, i, axis=0)  # 删除第 i 个样本，作为训练集
        test_sample = dise_mic_matrix[i, :]  # 第 i 个样本作为测试集

        drug_mic_res = PredictScore(train_matrix, dise_matrix, mic_matrix, sizes.seed, sizes)
        predict_y_proba = drug_mic_res.reshape(train_matrix.shape[0], train_matrix.shape[1]).detach().numpy()

        pre_matrix[i, :] = predict_y_proba[i, :]  # 存储预测结果

        metric_tmp, fpr, tpr = get_metrics(test_sample, predict_y_proba[i, :])

        metric_sum += metric_tmp  # 将当前指标添加到累积总和中
        fpr_sum += fpr
        tpr_sum += tpr

    metric_avg = metric_sum / dise_mic_matrix.shape[0]  # 计算平均指标
    fpr_avg = fpr_sum / dise_mic_matrix.shape[0]  # 计算平均 FPR
    tpr_avg = tpr_sum / dise_mic_matrix.shape[0]  # 计算平均 TPR

    return metric_avg, pre_matrix, fpr_avg, tpr_avg


def plot_roc_curve(fpr, tpr):
    # fpr, tpr, _ = roc_curve(dise_mic_matrix.flatten(), pre_matrix.flatten(), drop_intermediate=False)
    roc_auc = auc(fpr, tpr)

    plt.figure(dpi=100)
    plt.plot(fpr, tpr, color='darkorange', lw=1, label='ROC curve (area = {:.4f})'.format(roc_auc))
    plt.plot([0, 1], [0, 1], color='navy', lw=1, linestyle='--')
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic Curve')
    plt.legend(loc='lower right')

    # 设置x轴和y轴刻度间隔为0.1
    plt.xticks(np.arange(0, 1.1, 0.1))
    plt.yticks(np.arange(0, 1.1, 0.1))
    plt.grid(True, linestyle='-', alpha=0.6)


# def plot_aupr_curve(mean_recall, mean_precision, aupr_auc):

#     plt.figure()
#     plt.figure(figsize=(8, 6),dpi=100)
#     plt.plot(mean_recall, mean_precision, color='darkorange', lw=1, label='AUPR curve (area = {:.4f})'.format(aupr_auc))
#     plt.xlim([-0.05, 1.05])
#     plt.ylim([-0.05, 1.05])
#     plt.xlabel('Recall')
#     plt.ylabel('Precision')
#     plt.title('Precision-Recall Curve')
#     plt.legend(loc='lower left')

#     # 设置x轴和y轴刻度间隔为0.1
#     plt.xticks(np.arange(0, 1.1, 0.1))
#     plt.yticks(np.arange(0, 1.1, 0.1))

#     plt.show()

def plot_aupr_predict(recall,precision):

    aupr = auc(recall, precision)
    plt.figure(dpi=100)
    plt.plot(recall, precision, label=f'PR Curve (AUPR = {aupr:.4f})'.format(aupr), color='darkorange', lw=1)
    # plt.plot([0, 1], [0, 1], color='navy', lw=1, linestyle='--')
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve')
    plt.legend()
    plt.xticks(np.arange(0, 1.1, 0.1))
    plt.yticks(np.arange(0, 1.1, 0.1))
    plt.grid(True, linestyle='-', alpha=0.6)
    plt.show()


def save_roc_curve_data(file_path, fpr, tpr):
    with open(file_path, 'w') as file:
        for fpr_val, tpr_val in zip(fpr, tpr):
            file.write(f"{fpr_val} {tpr_val}\n")

if __name__ == "__main__":
    data_path = '../Data/MicrobeDrugA/'
    # data_set = 'aBiofilm/'
    data_set = 'MDAD/'
    # data_set = 'DrugVirus/'

    # dise_sim = np.loadtxt('E:\Lab_qi\code_paper\MKGCN-main-2\data\MicrobeDrugA\MDAD\drugsimilarity.txt', delimiter='\t')
    # mic_sim = np.loadtxt('E:\Lab_qi\code_paper\MKGCN-main-2\data\MicrobeDrugA\MDAD\microbesimilarity.txt', delimiter='\t')
    # adj_triple = np.loadtxt('E:\\Lab_qi\\code_paper\\MKGCN-main-2\\data\\MicrobeDrugA\\MDAD\\adj.txt') 

    # 自己的数据集MD
    dise_sim = np.loadtxt('E:\Lab_qi\code_paper\MKGCN-main-2\data\MicrobeDrugA\MDAD\disease_m.txt', delimiter='\t')
    mic_sim = np.loadtxt('E:\Lab_qi\code_paper\MKGCN-main-2\data\MicrobeDrugA\MDAD\microbe_m.txt', delimiter='\t')
    adj_triple = np.loadtxt('E:\\Lab_qi\\code_paper\\MKGCN-main-2\\data\\MicrobeDrugA\\MDAD\\adjm.txt') 

    
    # dise_sim = np.loadtxt('E:\\Lab_qi\\code_paper\\MKGCN-main-2\\data\\MicrobeDrugA\\aBiofilm\\disease_D.txt', delimiter='\t')
    # mic_sim = np.loadtxt('E:\\Lab_qi\\code_paper\\MKGCN-main-2\\data\\MicrobeDrugA\\aBiofilm\\microbe_D.txt', delimiter='\t')
    # adj_triple = np.loadtxt('E:\\Lab_qi\\code_paper\\MKGCN-main-2\\data\\MicrobeDrugA\\aBiofilm\\adj_D.txt') 
    
    # #peryton数据集
    # dise_sim = np.load('E:\Lab_qi\code_paper\MKGCN-main-2\data\MicrobeDrugA\peryton\sim_d.npy')
    # mic_sim = np.load('E:\Lab_qi\code_paper\MKGCN-main-2\data\MicrobeDrugA\peryton\sim_m.npy')
    # adj_triple = np.load('data/MicrobeDrugA/peryton/mic_dis association.npy') 
    # dise_mic_matrix=np.transpose(adj_triple)

    print(dise_sim.shape)
    print(mic_sim.shape)
    # print(dise_mic_matrix.shape)

    dise_mic_matrix = sp.csc_matrix((adj_triple[:, 2], (adj_triple[:, 0] - 1, adj_triple[:, 1] - 1)),
                                    shape=(len(dise_sim), len(mic_sim))).toarray() 
    MD_mat_new=WKNKN.WKNKN1(dise_mic_matrix,  dise_sim,mic_sim,7, 0.6)
    print(dise_mic_matrix.shape)
    df = pd.DataFrame(dise_mic_matrix)  # 将 NumPy 数组转换为 DataFrame
    df.to_csv('result1.csv', index=False)
    
    average_result = np.zeros((1, 7), float)
    circle_time = 1
    sizes = Sizes(dise_sim.shape[0], mic_sim.shape[0])#传递给里面
    results = []

    result, pre_matrix,fpr1,tpr1= cross_validation_experiment(
        MD_mat_new,  dise_sim,mic_sim, sizes)
    print(list(sizes.__dict__.values()) + result.tolist()[0][:2])
'''
    df = pd.DataFrame(pre_matrix)  # 将 NumPy 数组转换为 DataFrame
    df.to_csv('result.csv', index=False)
    pre_matrix1=pre_matrix-dise_mic_matrix
    # Exclude the first row and find the indices of the top five maximum values in each row of pre_matrix
    top_five_indices = np.argsort(pre_matrix[0:], axis=1)[:, -15:] 
    top_five_values = np.partition(pre_matrix[0:], -5, axis=1)[:, -5:]
    print(top_five_indices[:, ::-1])
    print("Indices of the top five maximum values in each row (excluding the first row):")
    print(top_five_values)
    # print(result[1])
    # 画 AUC 曲线 Precision-Recall 曲线
    plot_roc_curve(fpr1,tpr1)
    save_roc_curve_data("roc_curve_data.txt", fpr1, tpr1)
  
    precision, recall, _ = precision_recall_curve(dise_mic_matrix.flatten(), pre_matrix.flatten())
    save_roc_curve_data("pr_curve_data.txt", recall, precision)

    plot_aupr_predict(recall,precision)

    # 调用函数并捕获返回的 fpr 和 tpr 值
    fpr_values, tpr_values = plot_roc_curve(dise_mic_matrix, pre_matrix)

    # 现在您可以保存这些值到文件或者进行其他处理
    np.savetxt('roc_curve_data.txt', np.column_stack((fpr_values, tpr_values)), delimiter=',')

'''