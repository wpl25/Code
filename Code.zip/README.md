# DKNN-GCNMK
 **A Novel Approach for Microbe-Disease Prediction Combining Dilated KNN and Multi-Kernel* Graph Convolutional Networks**



# Dataset
1)HMDAD:http://www.cuilab.cn/hmdad), which includes 450 MDAs between 292 microbes and 39 diseases collected;

2)Disbiome (https://disbiome.ugent.be/home: comprising 4,351 MDAs between 1,052 microbes and 218 diseases。

# Requirements
* Python 3.7
* Pytorch
* PyTorch Geometric
* numpy
* scipy
