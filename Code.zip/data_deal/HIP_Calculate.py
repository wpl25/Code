# -*- coding: utf-8 -*-
# Auther : LiJingWei
# Date : 2023/4/4 14:18
# File : HIP_Calculate.py
import numpy as np
import pandas as pd
import torch as t

# 该代码实现的是HIP（Hamming distance-based Integrated similarity Profile）
# 方法，用于计算行之间的相似度。HIP方法通过计算两行之间的汉明距离来衡量它们之间的相
# 似性。具体而言，HIP将每个样本表示为一个二进制码的序列，然后比较它们之间的不同位数，
# 以此计算出它们之间的汉明距离。最终，通过将1减去汉明距离除以总位数，可以得到两个样
# 本之间的相似度。
# 加载CSV文件并将其转换为适当的输入矩阵
data = pd.read_csv('../data-3/MIC-DRUG/interaction.csv', header=None)
y = t.tensor(data.values)


def HIP_Calculate(M):
    l = len(M)
    cl = np.size(M, axis=1)
    SM = np.zeros((l, l))
    for i in range(l):
        for j in range(l):
            drum = 0
            for k in range(cl):
                if M[i][k] != M[j][k]:
                    drum = drum + 1
            SM[i][j] = 1 - drum / cl  # HIP计算出来的相似矩阵
    return SM


t = HIP_Calculate(y.T)
print(t.shape)
result = pd.DataFrame(t)

result.to_csv('../data-3/MIC-DRUG/microbe-HipSim.csv', index=False,header=False)
