# -*- coding: utf-8 -*-
# Auther : LiJingWei
# Date : 2023/5/22 18:50
# File : matrix-dealtwo.py
# 导入第一个CSV文件并转换为矩阵
import numpy as np

data1 = np.genfromtxt('../data-3/DrugVirus/drug-CosSim.csv', delimiter=',')
matrix1 = np.matrix(data1)

# 导入第二个CSV文件并转换为矩阵
data2 = np.genfromtxt('../data-3/DrugVirus/drug-GipSim.csv', delimiter=',')
matrix2 = np.matrix(data2)

condition = data2 != 0
result = np.where(condition,(data1 + data2)/2,data1)
np.savetxt('../data-3/DrugVirus/drug-Gip-Cos.csv', result, delimiter=',')