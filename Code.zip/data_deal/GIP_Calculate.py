# -*- coding: utf-8 -*-
# Auther : LiJingWei
# Date : 2023/4/15 10:48
# File : GIP_Calculate.py
import numpy as np
import math
# from utils import *
import pandas as pd

A = pd.read_csv('../MIC-DRUG/interaction.csv', header=None)
#添加header=None参数，以告诉pandas库该csv文件没有标题行，并将第一行作为有效数据。
A_array = A.values
print(A_array.shape)
print(A_array)
def GIP_Calculate(M):    #计算微生物高斯核相似性
    l=np.size(M,axis=1)#这行代码中，np.size(M,axis=1)的作用是获取输入数组M的列数。
    print(l)
    # 其中np.size()是numpy库中的函数，用于计算数组的元素总数，也可以指定参数axis表示计算某一维度上的元素个数。
    # 在本行代码中，指定axis=1表示要计算输入数组的列数。因此，l就是输入数组M的列数，也就是表示微生物数量的值。
    sm=[]
    m=np.zeros((l,l))
    for i in range(l):
        tmp=(np.linalg.norm(M[:,i]))**2
        sm.append(tmp)
    gama=l/np.sum(sm)
    for i in range(l):
        for j in range(l):
            m[i,j]=np.exp(-gama*((np.linalg.norm(M[:,i]-M[:,j]))**2))
    return m

Smg=GIP_Calculate(A_array)
print(Smg)
print(Smg.shape)
result = pd.DataFrame(Smg)
result.to_csv('../MIC-DRUG/microbe-GipSim.csv',index=False,header=None)



















# print(len(Smg))